In the lib directory stats.js is downloaded from https://github.com/mrdoob/stats.js/blob/master/build/stats.js.
And the code for stats.js is from the lab 2 to anylize the performance of the program. 