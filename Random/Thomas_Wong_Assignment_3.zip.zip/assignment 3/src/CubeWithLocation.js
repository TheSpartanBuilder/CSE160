class CubeWithLocation extends CubeTextureInUse
{
    constructor(config=null,location=null)
    {
        super(config);
        this.location = location;
    }
    
}