class Crosshair extends CubeTexture {
    constructor(u_SamplerX = null,textureID = null,gl_TEXTURE = null)
    {
        super("../Image/code/crosshair.png",u_SamplerX,textureID,gl_TEXTURE);
        // super("../Image/code/santa_bailey-256x256.png",u_SamplerX,textureID,gl_TEXTURE);
    }
}